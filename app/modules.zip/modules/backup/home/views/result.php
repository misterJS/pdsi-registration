<div class="card">
	<div class="card-header">
		<h5 class="card-title"><?=$current_module['judul_module']?></h5>
	</div>
	<div class="card-body">
		Selamat datang di PHP *	Year		: 2022 pdsionline.org
	</div>
</div>