<?php
/**
*	Aplikasi Kartu Professional
* 	Author	: Agus Prawoto Hadi
*	Website	: https://pdsionline.org
*	Year	: 2022
*/

$site_title = 'Home';
$data['title'] = 'Home';
load_view('views/result.php', $data);